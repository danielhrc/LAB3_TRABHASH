/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EspalhamentoLinear;



/**
 *
 * @author julio
 */
public class HashLinear {
    
    private int M; // @{\it tamanho da tabela}@
    private Lista tabela[];

    private int h(int chave) {
        return chave % this.M;

    }

    public HashLinear(int m) {
        this.M = m;
        this.tabela = new Lista[this.M];
        for (int i = 0; i < this.M; i++) {
            this.tabela[i] = new Lista();
        }
    }

    public Object pesquisa(Object chave) {
        int i = this.h((int) chave);
        if (this.tabela[i].vazia()) {
            return null; // @{\it pesquisa sem sucesso}@
        } else {
            Object obj = this.tabela[i].pesquisa(chave);
            if (obj == null) {
                return null; // @{\it pesquisa sem sucesso}@
            } else {
                return obj;
            }
        }
    }

    public void insere(Object chave) {
        if (this.pesquisa(chave) == null) {
            int i = this.h((int) chave) , j = 0;
            
            while(!this.tabela[this.h(i+j)].vazia() && j<this.M){
                j++;
            }
            if(j<this.M)
                this.tabela[i].insere(chave);
            else 
                System.out.println("Não há espaços para registro");
                
            
        } else {
            System.out.println("Registro ja esta presente");
        }
    }

    public void retira(Object chave) throws Exception {
        int i = this.h((int) chave);
        Object obj = this.tabela[i].retira(chave);
        if (obj == null) {
            System.out.println("Registro nao esta presente");
        }
    }

    public void imprime() {
        for (int i = 0; i < this.M; i++) {
            if (!this.tabela[i].vazia()) {
                System.out.println("Entrada: " + i);
                this.tabela[i].imprime();
            }
        }
    }
}


