
package EspalhamentoLinear;

public class testeHash2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        HashLinear hash = new HashLinear(2);
        hash.insere(5);
        hash.insere(2);
        hash.insere(3);
        hash.imprime();
        
    }
    
}
